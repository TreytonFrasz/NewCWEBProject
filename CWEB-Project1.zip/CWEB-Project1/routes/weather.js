var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
    res.render('Weather', { title: 'Weather Search' });
});

document.getElementById('weatherForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const location = document.getElementById('locationInput').value;
    const apiKey = ''; // Replace with API key
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${apiKey}`;

});

module.exports = router;